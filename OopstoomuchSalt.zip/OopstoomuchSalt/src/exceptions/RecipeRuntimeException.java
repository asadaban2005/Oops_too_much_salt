package exceptions;

/**
 * Runtime (unchecked) wrapper thrown by services when they don't want to force callers to handle checked exceptions.
 */
public class RecipeRuntimeException extends RuntimeException {
    public RecipeRuntimeException(String message) { super(message); }
    public RecipeRuntimeException(String message, Throwable cause) { super(message, cause); }
}
