package exceptions;

/**
 * Checked exception for recipe-related problems.
 */
public class RecipeException extends Exception {
    public RecipeException(String message) {
        super(message);
    }

    public RecipeException(String message, Throwable cause) {
        super(message, cause);
    }
}
