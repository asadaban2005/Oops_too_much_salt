package db;

import java.sql.Connection;

/**
 * Abstract base class to demonstrate abstraction for DB connectors.
 */
public abstract class DBBase {
    protected Connection connection;

    // concrete subclasses must implement how to create connection
    protected abstract Connection createConnection();

    // public accessor (ensures single connection per instance)
    public Connection getConnection() {
        if (connection == null) {
            connection = createConnection();
        }
        return connection;
    }
}
