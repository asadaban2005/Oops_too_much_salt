package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DatabaseConnection for MySQL. Singleton pattern, extends DBBase.
 * Update URL/USER/PASSWORD to match your MySQL installation.
 */
public class DatabaseConnection extends DBBase {

    private static final String URL = "jdbc:mysql://localhost:3306/oopstoomuchsalt?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root"; // change if needed
    private static final String PASSWORD = "password"; // change to your DB password

    private static DatabaseConnection instance;

    private DatabaseConnection() {
        // private constructor for singleton
    }

    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
            instance.getConnection(); // attempt to create connection immediately
        }
        return instance;
    }

    @Override
    protected Connection createConnection() {
        try {
            // Load MySQL driver (not mandatory on modern JVMs but safe)
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database connected successfully!");
            return conn;
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            e.printStackTrace();
        }
        return null;
    }

    // convenience accessor used by services
    public static Connection getConnection() {
        return getInstance().getConnection();
    }

    // close connection if needed
    public static void closeConnection() {
        Connection conn = getInstance().connection;
        if (conn != null) {
            try {
                conn.close();
                getInstance().connection = null;
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
