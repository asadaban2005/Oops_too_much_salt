package services;

import java.util.List;
import models.Recipe;

/**
 * Interface/contract for recipe services.
 *
 * NOTE: methods use simple signatures (String name) to stay compatible with your GUI's current usage.
 */
public interface IRecipeService {
    void addRecipe(Recipe recipe);
    java.util.List<Recipe> getAllRecipes();
    void updateRecipe(String originalName, Recipe updatedRecipe);
    void deleteRecipe(String name);
}
