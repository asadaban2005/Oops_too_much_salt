// Update a recipe by original name
public void updateRecipe(String originalName, Recipe updatedRecipe) {
    String sql = "UPDATE recipes SET name=?, ingredients=?, instructions=? WHERE name=?";
    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
        pstmt.setString(1, updatedRecipe.getName());
        pstmt.setString(2, updatedRecipe.getIngredients());
        pstmt.setString(3, updatedRecipe.getInstructions());
        pstmt.setString(4, originalName);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

// Delete a recipe by name
public void deleteRecipe(String name) {
    String sql = "DELETE FROM recipes WHERE name=?";
    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
        pstmt.setString(1, name);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
