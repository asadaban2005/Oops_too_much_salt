package services;

import db.DatabaseConnection;
import exceptions.RecipeRuntimeException;
import models.Recipe;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * RecipeService: concrete implementation of IRecipeService using MySQL via DatabaseConnection.
 * Provides add/getAll/update/delete operations.
 */
public class RecipeService implements IRecipeService {

    private Connection connection;

    public RecipeService() {
        this.connection = DatabaseConnection.getConnection();
    }

    // ---------------- ADD ----------------
    @Override
    public void addRecipe(Recipe recipe) {
        String sql = "INSERT INTO recipes (name, ingredients, instructions) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, recipe.getName());
            pstmt.setString(2, recipe.getIngredients());
            pstmt.setString(3, recipe.getInstructions());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RecipeRuntimeException("Failed to add recipe: " + recipe.getName(), e);
        }
    }

    // ---------------- READ ----------------
    @Override
    public List<Recipe> getAllRecipes() {
        List<Recipe> list = new ArrayList<>();
        String sql = "SELECT name, ingredients, instructions FROM recipes ORDER BY name";
        try (PreparedStatement pstmt = connection.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Recipe r = new Recipe(
                        rs.getString("name"),
                        rs.getString("ingredients"),
                        rs.getString("instructions")
                );
                list.add(r);
            }
        } catch (SQLException e) {
            throw new RecipeRuntimeException("Failed to fetch recipes", e);
        }
        return list;
    }

    // ---------------- UPDATE ----------------
    /**
     * Updates the recipe identified by originalName with values in updatedRecipe.
     * Note: We keep the same signature your GUI uses (originalName string).
     */
    @Override
    public void updateRecipe(String originalName, Recipe updatedRecipe) {
        String sql = "UPDATE recipes SET name = ?, ingredients = ?, instructions = ? WHERE name = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, updatedRecipe.getName());
            pstmt.setString(2, updatedRecipe.getIngredients());
            pstmt.setString(3, updatedRecipe.getInstructions());
            pstmt.setString(4, originalName);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RecipeRuntimeException("Failed to update recipe: " + originalName, e);
        }
    }

    // ---------------- DELETE ----------------
    @Override
    public void deleteRecipe(String name) {
        String sql = "DELETE FROM recipes WHERE name = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RecipeRuntimeException("Failed to delete recipe: " + name, e);
        }
    }
}
