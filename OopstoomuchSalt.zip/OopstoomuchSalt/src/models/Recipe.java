package models;

/**
 * Recipe model with encapsulation.
 */
public class Recipe {
    private String name;
    private String ingredients;
    private String instructions;
    private String category; // optional; can be used by subclasses

    public Recipe() {}

    public Recipe(String name, String ingredients, String instructions) {
        this.name = name;
        this.ingredients = ingredients;
        this.instructions = instructions;
    }

    public Recipe(String name, String category, String ingredients, String instructions) {
        this.name = name;
        this.category = category;
        this.ingredients = ingredients;
        this.instructions = instructions;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getIngredients() { return ingredients; }
    public void setIngredients(String ingredients) { this.ingredients = ingredients; }

    public String getInstructions() { return instructions; }
    public void setInstructions(String instructions) { this.instructions = instructions; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    /**
     * Polymorphic hook - subclasses can override to present category differently.
     */
    public String displayCategory() {
        return (category == null || category.trim().isEmpty()) ? "Other" : category;
    }

    @Override
    public String toString() {
        return "Recipe{name='" + name + "', category='" + category + "'}";
    }
}
