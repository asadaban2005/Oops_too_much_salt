package models;

public class NonVegRecipe extends Recipe {
    public NonVegRecipe(String name, String ingredients, String instructions) {
        super(name, "Non-Veg", ingredients, instructions);
    }

    @Override
    public String displayCategory() {
        return "Non-Veg";
    }
}
