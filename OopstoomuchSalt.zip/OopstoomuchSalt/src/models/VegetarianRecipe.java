package models;

public class VegetarianRecipe extends Recipe {
    public VegetarianRecipe(String name, String ingredients, String instructions) {
        super(name, "Vegetarian", ingredients, instructions);
    }

    @Override
    public String displayCategory() {
        return "Vegetarian";
    }
}
