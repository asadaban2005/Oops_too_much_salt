package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import services.RecipeService;
import models.Recipe;

public class MainWindow extends JFrame {

    private RecipeService recipeService;
    private DefaultTableModel tableModel;
    private JTable table;
    private TableRowSorter<DefaultTableModel> rowSorter;

    public MainWindow() {
        recipeService = new RecipeService();
        setTitle("🍲 Oops Too Much Salt");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ---------- Table Setup ----------
        tableModel = new DefaultTableModel(new String[]{"Name", "Ingredients", "Instructions"}, 0);
        table = new JTable(tableModel);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.setRowHeight(25);
        refreshTable();

        rowSorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(rowSorter);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Recipes"));

        // ---------- Search Panel ----------
        JPanel searchPanel = new JPanel(new BorderLayout(10, 10));
        JLabel searchLabel = new JLabel("🔍 Search:");
        searchLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        JTextField searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        searchPanel.add(searchLabel, BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Filter listener
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(searchField.getText()); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(searchField.getText()); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(searchField.getText()); }
            private void filter(String text) {
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });

        // ---------- Buttons ----------
        JPanel buttonPanel = new JPanel();
        JButton addButton = createButton("➕ Add Recipe");
        JButton editButton = createButton("✏️ Edit Selected");
        JButton deleteButton = createButton("🗑 Delete Selected");

        addButton.addActionListener(e -> openRecipeForm());
        editButton.addActionListener(e -> editSelectedRecipe());
        deleteButton.addActionListener(e -> deleteSelectedRecipe());

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ---------- Main Layout ----------
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.add(searchPanel, BorderLayout.NORTH);
        mainPanel.add(tableScroll, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(mainPanel);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 35));
        return button;
    }

    private void openRecipeForm() {
        RecipeForm form = new RecipeForm(this, recipeService);
        form.setVisible(true);
    }

    private void editSelectedRecipe() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a recipe to edit.");
            return;
        }

        String name = (String) tableModel.getValueAt(table.convertRowIndexToModel(selectedRow), 0);
        String ingredients = (String) tableModel.getValueAt(table.convertRowIndexToModel(selectedRow), 1);
        String instructions = (String) tableModel.getValueAt(table.convertRowIndexToModel(selectedRow), 2);

        JTextField nameField = new JTextField(name);
        JTextField ingredientsField = new JTextField(ingredients);
        JTextArea instructionsArea = new JTextArea(instructions, 5, 20);
        instructionsArea.setLineWrap(true);
        instructionsArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(instructionsArea);

        Object[] message = {
            "Name:", nameField,
            "Ingredients:", ingredientsField,
            "Instructions:", scrollPane
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Edit Recipe", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            Recipe updatedRecipe = new Recipe(
                nameField.getText(),
                ingredientsField.getText(),
                instructionsArea.getText()
            );
            recipeService.updateRecipe(name, updatedRecipe);
            refreshTable();
        }
    }

    private void deleteSelectedRecipe() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a recipe to delete.");
            return;
        }

        String name = (String) tableModel.getValueAt(table.convertRowIndexToModel(selectedRow), 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete \"" + name + "\"?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            recipeService.deleteRecipe(name);
            refreshTable();
        }
    }

    public void refreshTable() {
        tableModel.setRowCount(0);
        for (Recipe r : recipeService.getAllRecipes()) {
            tableModel.addRow(new Object[]{r.getName(), r.getIngredients(), r.getInstructions()});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}
