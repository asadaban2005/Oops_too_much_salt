package gui;

import javax.swing.*;
import java.awt.*;
import services.RecipeService;
import models.Recipe;

public class RecipeForm extends JDialog {

    private JTextField nameField, ingredientsField;
    private JTextArea instructionsArea;
    private RecipeService recipeService;
    private MainWindow mainWindow;

    public RecipeForm(MainWindow parent, RecipeService recipeService) {
        super(parent, "➕ Add Recipe", true);
        this.mainWindow = parent;
        this.recipeService = recipeService;

        setSize(450, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        // ---------- Input Panel ----------
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Name:"), gbc);

        gbc.gridx = 1;
        nameField = new JTextField();
        nameField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        inputPanel.add(nameField, gbc);

        // Ingredients
        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Ingredients:"), gbc);

        gbc.gridx = 1;
        ingredientsField = new JTextField();
        ingredientsField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        inputPanel.add(ingredientsField, gbc);

        // Instructions
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        inputPanel.add(new JLabel("Instructions:"), gbc);

        gbc.gridx = 1;
        instructionsArea = new JTextArea(6, 20);
        instructionsArea.setLineWrap(true);
        instructionsArea.setWrapStyleWord(true);
        instructionsArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(instructionsArea);
        inputPanel.add(scrollPane, gbc);

        add(inputPanel, BorderLayout.CENTER);

        // ---------- Button Panel ----------
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Recipe");
        addButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        addButton.setBackground(new Color(70, 130, 180));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.setPreferredSize(new Dimension(150, 35));

        addButton.addActionListener(e -> addRecipe());
        buttonPanel.add(addButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void addRecipe() {
        String name = nameField.getText().trim();
        String ingredients = ingredientsField.getText().trim();
        String instructions = instructionsArea.getText().trim();

        if (name.isEmpty() || ingredients.isEmpty() || instructions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Recipe recipe = new Recipe(name, ingredients, instructions);
        recipeService.addRecipe(recipe);
        mainWindow.refreshTable();
        dispose();
    }
}
